# Case Study 31: String-Based Examination Answer Evaluation

## 1. Problem Statement
Compare student answer strings with an answer key, count correct, incorrect, and unanswered responses, apply negative marking, and produce a result.

## 2. Objectives
- Compare answers question by question.
- Count correct, incorrect, and blank responses.
- Calculate marks after negative marking.

## 3. Assumptions
- Each correct answer earns 4 marks.
- Each incorrect non-blank answer loses 1 mark.
- An unanswered response earns 0 marks.
- Answers are compared without case sensitivity; surrounding spaces are removed.

## 4. Algorithm
1. Store the answer key and student's answers as lists of strings.
2. Check that both lists have equal length.
3. Normalize each response using strip and upper.
4. Compare each response with the key.
5. Update correct, incorrect, or unanswered counts and marks.
6. Display the final result.

## 5. Flowchart
The diagram below shows the overall program flow. Detailed case-specific decisions are implemented in `solution.py`.

![Flowchart](flowchart.png)

## 6. Pseudocode
```text
START
SET answer_key and student_answers
IF list lengths differ, REPORT error
SET correct = incorrect = unanswered = 0; marks = 0
FOR each question index
  NORMALIZE student's answer
  IF answer is blank, increment unanswered
  ELSE IF answer equals key, increment correct and add 4
  ELSE increment incorrect and subtract 1
END FOR
DISPLAY counts and final marks
STOP
```

## 7. Python Source Code
See [`solution.py`](solution.py). The program uses Python built-in features and no third-party packages.

## 8. Test Cases

| Test | Input / condition | Expected result |
|---|---|---|
| Correct response | Key A; response A | 4 marks |
| Incorrect response | Key A; response B | -1 mark |
| Blank response | Key A; response empty string | 0 marks; unanswered increases |
| Case and spaces | Key 'a'; response ' A ' | Correct after normalization |
| Length mismatch | Key has 2 entries; answers have 1 | ValueError is raised |

## Sample Output
The included program was run with the sample data in `main()`. The captured output is also saved as `sample_output.txt`.

![Sample output screenshot](output_screenshot.png)

## 9. Output Screenshot
This terminal-style screenshot is a generated capture of the sample program output. Run `python solution.py` to reproduce it.

## 10. Conclusion
The program evaluates answer strings, applies positive and negative marking, and produces a question-wise report using lists, loops, strings, and conditions.
