# Case Study 31: String-Based Examination Answer Evaluation

def evaluate_answers(answer_key, student_answers):
    if len(answer_key) != len(student_answers):
        raise ValueError("Answer key and response list must have equal length.")

    correct = 0
    incorrect = 0
    unanswered = 0
    marks = 0
    details = []

    for index in range(len(answer_key)):
        expected = answer_key[index].strip().upper()
        response = student_answers[index].strip().upper()

        if response == "":
            unanswered += 1
            result = "UNANSWERED"
        elif response == expected:
            correct += 1
            marks += 4
            result = "CORRECT"
        else:
            incorrect += 1
            marks -= 1
            result = "INCORRECT"
        details.append((index + 1, expected, response or "-", result))

    return details, correct, incorrect, unanswered, marks


def main():
    key = ["A", "C", "B", "D", "A", "C"]
    answers = ["a", "B", "B", "", "A", "d"]
    details, correct, incorrect, unanswered, marks = evaluate_answers(key, answers)

    print("EXAMINATION ANSWER EVALUATION")
    print("-" * 52)
    for number, expected, response, result in details:
        print(f"Q{number}: Key={expected} | Answer={response:3} | {result}")
    print("-" * 52)
    print(f"Correct: {correct} | Incorrect: {incorrect} | Unanswered: {unanswered}")
    print(f"Final marks: {marks} out of {len(key) * 4}")


if __name__ == "__main__":
    main()
