# Case Study 17: Student Performance Trend Analysis

## 1. Problem Statement
Compare student scores in successive examinations, calculate subject-wise changes, identify weak subjects, and classify overall performance.

## 2. Objectives
- Store subject scores for two examinations.
- Calculate improvement or decline for each subject.
- Identify weak subjects and classify the student's trend.

## 3. Assumptions
- Scores are out of 100 and must be between 0 and 100.
- A score below 40 is considered weak.
- An overall average change of +5 or more is Improving; -5 or less is Declining; otherwise Stable.

## 4. Algorithm
1. Store subject names and two score lists.
2. Validate that both lists have the same length and all scores are valid.
3. Calculate the difference for each subject.
4. Identify subjects with a latest score below 40.
5. Calculate both averages and their difference.
6. Classify the overall trend and display the report.

## 5. Flowchart
The diagram below shows the overall program flow. Detailed case-specific decisions are implemented in `solution.py`.

![Flowchart](flowchart.png)

## 6. Pseudocode
```text
START
READ subjects, previous_scores, latest_scores
VALIDATE list lengths and score range
SET total_previous = 0 and total_latest = 0
FOR each subject index
  difference = latest score - previous score
  ADD scores to their respective totals
  IF latest score < 40, mark subject as weak
END FOR
CALCULATE average change
IF change ≥ 5, trend = Improving
ELSE IF change ≤ -5, trend = Declining
ELSE trend = Stable
DISPLAY subject changes, weak subjects, averages, and trend
STOP
```

## 7. Python Source Code
See [`solution.py`](solution.py). The program uses Python built-in features and no third-party packages.

## 8. Test Cases

| Test | Input / condition | Expected result |
|---|---|---|
| Improvement | Previous [50, 60], latest [60, 70] | Average change +10; Improving |
| Decline | Previous [80, 70], latest [70, 60] | Average change -10; Declining |
| Stable | Previous [60, 60], latest [62, 58] | Average change 0; Stable |
| Weak subject | Latest score 35 | Subject is included in weak-subject list |
| Invalid score | Latest score 105 | ValueError is raised |

## Sample Output
The included program was run with the sample data in `main()`. The captured output is also saved as `sample_output.txt`.

![Sample output screenshot](output_screenshot.png)

## 9. Output Screenshot
This terminal-style screenshot is a generated capture of the sample program output. Run `python solution.py` to reproduce it.

## 10. Conclusion
The program compares successive examination results, detects weak subjects, and classifies the overall trend using lists, indexing, loops, and conditional statements.
