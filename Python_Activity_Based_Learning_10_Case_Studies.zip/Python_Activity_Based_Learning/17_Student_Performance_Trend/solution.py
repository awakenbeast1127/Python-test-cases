# Case Study 17: Student Performance Trend Analysis

def analyse_performance(subjects, previous_scores, latest_scores):
    if not (len(subjects) == len(previous_scores) == len(latest_scores)):
        raise ValueError("All lists must contain the same number of subjects.")
    if len(subjects) == 0:
        raise ValueError("At least one subject is required.")

    for score in previous_scores + latest_scores:
        if score < 0 or score > 100:
            raise ValueError("Scores must be between 0 and 100.")

    changes = []
    weak_subjects = []
    for index in range(len(subjects)):
        change = latest_scores[index] - previous_scores[index]
        changes.append((subjects[index], change))
        if latest_scores[index] < 40:
            weak_subjects.append(subjects[index])

    previous_average = sum(previous_scores) / len(subjects)
    latest_average = sum(latest_scores) / len(subjects)
    average_change = latest_average - previous_average

    if average_change >= 5:
        trend = "Improving"
    elif average_change <= -5:
        trend = "Declining"
    else:
        trend = "Stable"

    return changes, weak_subjects, previous_average, latest_average, trend


def main():
    subjects = ["Python", "Mathematics", "Physics", "English"]
    previous = [55, 62, 38, 70]
    latest = [68, 60, 45, 78]
    changes, weak, old_avg, new_avg, trend = analyse_performance(subjects, previous, latest)

    print("STUDENT PERFORMANCE TREND")
    print("-" * 46)
    for subject, change in changes:
        print(f"{subject:15}: {change:+.1f} marks")
    print(f"Weak subjects (latest score below 40): {weak if weak else 'None'}")
    print(f"Previous average: {old_avg:.2f}")
    print(f"Latest average:   {new_avg:.2f}")
    print(f"Overall trend:    {trend}")


if __name__ == "__main__":
    main()
