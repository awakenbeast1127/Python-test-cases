# Case Study 49: Tuple-Based Product Catalogue Audit

def audit_catalogue(products, reorder_level=5):
    seen_ids = []
    duplicate_ids = []
    invalid_records = []
    reorder_items = []
    total_inventory_value = 0

    for product in products:
        product_id, name, price, stock = product  # tuple unpacking

        if product_id in seen_ids:
            duplicate_ids.append(product_id)
        else:
            seen_ids.append(product_id)

        if price < 0 or stock < 0:
            invalid_records.append(product_id)
            continue

        total_inventory_value += price * stock
        if stock < reorder_level:
            reorder_items.append((product_id, name, stock))

    return total_inventory_value, duplicate_ids, invalid_records, reorder_items


def main():
    products = [
        ("P101", "Keyboard", 750, 12),
        ("P102", "Mouse", 350, 3),
        ("P103", "Monitor", 6500, 4),
        ("P102", "Mouse - duplicate ID", 300, 2),
        ("P104", "USB Cable", 120, -1),
    ]
    value, duplicates, invalid, reorder = audit_catalogue(products)

    print("PRODUCT CATALOGUE AUDIT")
    print("-" * 46)
    print(f"Total inventory value (valid records): Rs.{value:.2f}")
    print(f"Duplicate product IDs: {duplicates if duplicates else 'None'}")
    print(f"Invalid records: {invalid if invalid else 'None'}")
    print("Items requiring replenishment:")
    for product_id, name, stock in reorder:
        print(f"  {product_id} - {name}: {stock} units")


if __name__ == "__main__":
    main()
