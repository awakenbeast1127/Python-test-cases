# Case Study 49: Tuple-Based Product Catalogue Audit

## 1. Problem Statement
Audit product records stored in tuples, detect invalid prices and stock values, calculate inventory value, and identify items requiring replenishment.

## 2. Objectives
- Store product data in tuples.
- Validate product identifiers, prices, and stock quantities.
- Calculate total inventory value.
- Identify products below the reorder level.

## 3. Assumptions
- Each record is (product_id, product_name, price, stock_quantity).
- Price and stock cannot be negative.
- A product needs replenishment when stock is below 5 units.
- Product IDs should be unique.

## 4. Algorithm
1. Read product tuples.
2. Track product IDs to detect duplicates.
3. Validate price and stock values.
4. For valid records, calculate price multiplied by stock.
5. Identify products whose stock is below 5.
6. Display valid inventory value and audit warnings.

## 5. Flowchart
The diagram below shows the overall program flow. Detailed case-specific decisions are implemented in `solution.py`.

![Flowchart](flowchart.png)

## 6. Pseudocode
```text
START
SET catalogue to list of product tuples
CREATE empty seen_ids list; total_value = 0
FOR each product tuple
  UNPACK product_id, name, price, stock
  IF product_id already seen, REPORT duplicate
  ELSE ADD product_id to seen_ids
  IF price < 0 OR stock < 0, REPORT invalid record
  ELSE ADD price × stock to total_value
    IF stock < 5, ADD product to reorder list
END FOR
DISPLAY inventory value, duplicate IDs, invalid records, reorder list
STOP
```

## 7. Python Source Code
See [`solution.py`](solution.py). The program uses Python built-in features and no third-party packages.

## 8. Test Cases

| Test | Input / condition | Expected result |
|---|---|---|
| Valid product | Price ₹500, stock 10 | Inventory value contribution ₹5,000 |
| Low stock | Stock 3 | Item appears in reorder list |
| Duplicate ID | Two records with P102 | P102 is reported as duplicate |
| Negative stock | Stock -1 | Record is invalid and excluded from value |
| Zero stock | Stock 0 | Valid numeric record; item requires replenishment |

## Sample Output
The included program was run with the sample data in `main()`. The captured output is also saved as `sample_output.txt`.

![Sample output screenshot](output_screenshot.png)

## 9. Output Screenshot
This terminal-style screenshot is a generated capture of the sample program output. Run `python solution.py` to reproduce it.

## 10. Conclusion
The audit checks tuple-based catalogue records, finds duplicate identifiers and invalid quantities, calculates stock value, and identifies replenishment needs.
