# Case Study 13: ATM Transaction Sequence Simulation

## 1. Problem Statement
Simulate a bank account by processing deposits and withdrawals, enforcing transaction rules, rejecting invalid operations, and producing a transaction summary.

## 2. Objectives
- Maintain an account balance across a sequence of transactions.
- Validate transaction amounts and withdrawal limits.
- Record accepted and rejected transactions and summarize them.

## 3. Assumptions
- The opening balance is ₹5,000.
- A withdrawal cannot exceed the available balance.
- A single withdrawal is limited to ₹3,000.
- Only positive amounts are accepted.

## 4. Algorithm
1. Set the opening balance and transaction limits.
2. Process each transaction tuple in order.
3. For deposits, add a valid positive amount.
4. For withdrawals, check positivity, per-transaction limit, and available balance.
5. Record the result and continue to the next transaction.
6. Display final balance and transaction counts.

## 5. Flowchart
The diagram below shows the overall program flow. Detailed case-specific decisions are implemented in `solution.py`.

![Flowchart](flowchart.png)

## 6. Pseudocode
```text
START
SET balance = 5000 and withdrawal_limit = 3000
SET accepted and rejected counts to 0
FOR each (transaction_type, amount)
  IF amount ≤ 0, REJECT
  ELSE IF type is DEPOSIT, ADD amount to balance
  ELSE IF type is WITHDRAWAL
    IF amount > withdrawal_limit, REJECT
    ELSE IF amount > balance, REJECT
    ELSE SUBTRACT amount from balance
  ELSE REJECT unknown type
  RECORD result
END FOR
DISPLAY transaction log, counts, and balance
STOP
```

## 7. Python Source Code
See [`solution.py`](solution.py). The program uses Python built-in features and no third-party packages.

## 8. Test Cases

| Test | Input / condition | Expected result |
|---|---|---|
| Deposit | Deposit ₹2,000 into ₹5,000 | Accepted; balance ₹7,000 |
| Valid withdrawal | Withdraw ₹1,500 | Accepted; balance ₹5,500 after sample's first two transactions |
| Limit violation | Withdraw ₹4,000 | Rejected; exceeds ₹3,000 limit |
| Insufficient funds | Withdraw ₹7,000 when balance is ₹5,500 | Rejected; balance unchanged |
| Invalid amount | Deposit ₹0 | Rejected; amount must be positive |

## Sample Output
The included program was run with the sample data in `main()`. The captured output is also saved as `sample_output.txt`.

![Sample output screenshot](output_screenshot.png)

## 9. Output Screenshot
This terminal-style screenshot is a generated capture of the sample program output. Run `python solution.py` to reproduce it.

## 10. Conclusion
The simulation maintains a running balance, validates each operation, and records accepted and rejected transactions using tuples, loops, conditions, and lists.
