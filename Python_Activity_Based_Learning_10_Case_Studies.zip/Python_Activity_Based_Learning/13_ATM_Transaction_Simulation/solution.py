# Case Study 13: ATM Transaction Sequence Simulation

def process_transactions(opening_balance, transactions, withdrawal_limit=3000):
    if opening_balance < 0:
        raise ValueError("Opening balance cannot be negative.")

    balance = opening_balance
    log = []
    accepted = 0
    rejected = 0

    for transaction in transactions:
        transaction_type, amount = transaction  # tuple unpacking
        kind = transaction_type.upper()
        reason = ""

        if amount <= 0:
            reason = "Amount must be positive"
        elif kind == "DEPOSIT":
            balance += amount
        elif kind == "WITHDRAWAL":
            if amount > withdrawal_limit:
                reason = "Exceeds single-withdrawal limit"
            elif amount > balance:
                reason = "Insufficient balance"
            else:
                balance -= amount
        else:
            reason = "Unknown transaction type"

        status = "REJECTED" if reason else "ACCEPTED"
        if reason:
            rejected += 1
        else:
            accepted += 1
        log.append((kind, amount, status, reason, balance))

    return balance, log, accepted, rejected


def main():
    transactions = [
        ("DEPOSIT", 2000),
        ("WITHDRAWAL", 1500),
        ("WITHDRAWAL", 4000),
        ("WITHDRAWAL", 7000),
        ("DEPOSIT", 0),
        ("TRANSFER", 500),
    ]
    balance, log, accepted, rejected = process_transactions(5000, transactions)

    print("ATM TRANSACTION SUMMARY")
    print("-" * 68)
    for kind, amount, status, reason, current_balance in log:
        detail = f" - {reason}" if reason else ""
        print(f"{kind:12} Rs.{amount:8.2f}  {status:8}{detail}")
        print(f"  Balance after transaction: Rs.{current_balance:.2f}")
    print("-" * 68)
    print(f"Accepted: {accepted} | Rejected: {rejected}")
    print(f"Final balance: Rs.{balance:.2f}")


if __name__ == "__main__":
    main()
